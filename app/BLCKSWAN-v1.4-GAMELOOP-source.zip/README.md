# BLCKSWAN v1.4 GAMELOOP source

The live web source is the same game logic published in the repository at:

https://github.com/bspippi1337/blckswan/blob/main/app/index.html

Android build source package from the ChatGPT build session:
BLCKSWAN-v1.4-GAMELOOP-source.zip

APK SHA-256:
8654e5d8a85b11da7e3e93aac5ca12bdf93ddd0ef8e9e6315b4558c6140db374

Core loop:
FRIHET + KUNNSKAP + TEST + REVISJON
